WOKWI PROJECT - IoT CHONG TROM XE MAY
Author: Nguyen Anh Duc

1. Mo project ESP32 tren Wokwi.
2. Copy diagram.json vao tab diagram.json.
3. Copy sketch.ino vao tab sketch.ino.
4. Copy libraries.txt neu Wokwi chua tu them thu vien.
5. Tat dich trang Cốc Cốc neu code bi doi thanh tieng Viet.
6. Bam Start Simulation.

GPIO:
PIR OUT  -> 27
MPU SDA  -> 21
MPU SCL  -> 22
START    -> 25
STOP     -> 26
LED      -> 2
BUZZER   -> 4

START: bat che do bao ve.
STOP: tat che do bao ve.
PIR: phat hien chuyen dong.
MPU6050: phat hien rung.
LED + Buzzer: canh bao.
MQTT topics:
xe_may/status
xe_may/canh_bao
