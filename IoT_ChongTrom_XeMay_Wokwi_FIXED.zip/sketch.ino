#include <Wire.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <math.h>

const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";

const char* MQTT_SERVER = "mqtt.eclipseprojects.io";
const int MQTT_PORT = 1883;

WiFiClient wifiClient;
PubSubClient mqtt(wifiClient);
Adafruit_MPU6050 mpu;

const int PIR_PIN = 27;
const int START_PIN = 25;
const int STOP_PIN = 26;
const int LED_PIN = 2;
const int BUZZER_PIN = 4;

bool systemOn = false;
unsigned long lastAlarm = 0;

void connectWiFi() {
  Serial.print("Connecting WiFi");

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int retry = 0;
  while (WiFi.status() != WL_CONNECTED && retry < 30) {
    delay(500);
    Serial.print(".");
    retry++;
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("WiFi connected");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("WiFi not connected");
  }
}

void connectMQTT() {
  if (WiFi.status() != WL_CONNECTED) {
    return;
  }

  if (mqtt.connected()) {
    return;
  }

  String clientId = "ESP32-XeMay-" + String((uint32_t)ESP.getEfuseMac(), HEX);

  Serial.print("Connecting MQTT... ");

  if (mqtt.connect(clientId.c_str())) {
    Serial.println("OK");
    mqtt.publish("xe_may/status", "ESP32 connected");
  } else {
    Serial.print("FAILED, state=");
    Serial.println(mqtt.state());
  }
}

void alarmOn(const char* message) {
  digitalWrite(LED_PIN, HIGH);
  tone(BUZZER_PIN, 2000);

  Serial.print("ALARM: ");
  Serial.println(message);

  if (mqtt.connected()) {
    mqtt.publish("xe_may/canh_bao", message);
  }

  lastAlarm = millis();
}

void alarmOff() {
  digitalWrite(LED_PIN, LOW);
  noTone(BUZZER_PIN);
}

void setup() {
  Serial.begin(115200);

  pinMode(PIR_PIN, INPUT);
  pinMode(START_PIN, INPUT_PULLUP);
  pinMode(STOP_PIN, INPUT_PULLUP);

  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  alarmOff();

  Wire.begin(21, 22);

  if (!mpu.begin()) {
    Serial.println("MPU6050 not found");
    while (true) {
      digitalWrite(LED_PIN, HIGH);
      delay(200);
      digitalWrite(LED_PIN, LOW);
      delay(200);
    }
  }

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  connectWiFi();

  mqtt.setServer(MQTT_SERVER, MQTT_PORT);

  Serial.println("==============================");
  Serial.println("IoT MOTORBIKE ANTI-THEFT");
  Serial.println("Press START to arm");
  Serial.println("Press STOP to disarm");
  Serial.println("==============================");
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    connectMQTT();
    mqtt.loop();
  }

  if (digitalRead(START_PIN) == LOW) {
    systemOn = true;
    alarmOff();
    Serial.println("SYSTEM ON");

    if (mqtt.connected()) {
      mqtt.publish("xe_may/status", "SYSTEM ON");
    }

    delay(300);
  }

  if (digitalRead(STOP_PIN) == LOW) {
    systemOn = false;
    alarmOff();
    Serial.println("SYSTEM OFF");

    if (mqtt.connected()) {
      mqtt.publish("xe_may/status", "SYSTEM OFF");
    }

    delay(300);
  }

  if (!systemOn) {
    alarmOff();
    delay(50);
    return;
  }

  bool motion = digitalRead(PIR_PIN) == HIGH;

  sensors_event_t accel, gyro, temp;
  mpu.getEvent(&accel, &gyro, &temp);

  float ax = accel.acceleration.x;
  float ay = accel.acceleration.y;
  float az = accel.acceleration.z;

  float magnitude = sqrt(ax * ax + ay * ay + az * az);

  bool vibration = (magnitude > 13.0 || magnitude < 7.0);

  if (motion || vibration) {
    if (millis() - lastAlarm >= 2000) {
      if (motion && vibration) {
        alarmOn("Motion and vibration detected");
      } else if (motion) {
        alarmOn("Motion detected");
      } else {
        alarmOn("Vehicle vibration detected");
      }
    }
  } else if (millis() - lastAlarm > 1000) {
    alarmOff();
  }

  delay(50);
}